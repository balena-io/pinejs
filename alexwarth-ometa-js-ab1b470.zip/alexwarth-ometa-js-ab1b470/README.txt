The following files contain some important info:

* Not_Quite_JS.txt explains the difference between "real" JavaScript and
  the JavaScript that can be used in the OMeta/JS Workspace.

* Things_You_Should_Know.txt explains the differences between the original
  OMeta syntax (as it appeared in the DLS'07 paper) and the newer OMeta/js
  syntax.

* OMeta_Tutorial.txt contains a bunch of examples that show how OMeta
  can be used for pattern matching, parsing, etc.

Another good resource for OMeta programmers is the OMeta mailing list. To
subscribe, please visit:

    http://vpri.org/mailman/listinfo/ometa

And you can also browse the archives of the mailing list at:

    http://vpri.org/pipermail/ometa/

Cheers,
Alex 

